After taking time off programming, I did the calculator project as means to revise Javascript basics. 

The basics of programming involve capturing, processing, and presenting data. A calculator accepts user input and processes the data using operations, such as division and display the result to the user. Additionally, the Create, Read, Update, and Delete (CRUD) are essential operations to understand. This project will neglect the aforementioned focusing on the capturing, processing, and displaying of data. 

Programme
Input: 
(1) Identify the user input mechanism, typically through buttons for numbers, arithmetic operations, and clear functions.
(2) Set up event listeners for each button to capture user input.

Process: 
(3) Create functions to handle different types of operations (addition, subtraction, multiplication, division).
(4) Implement logic to store and update the current input from the user.
(5) Handle arithmetic operations based on user input and the current state of the calculator.
(6) Ensure error handling for invalid inputs or operations (such as division by zero).

Output: 
(7) Display the current input and result on the calculator screen in real-time.
(8) Update the display dynamically as the user inputs numbers or performs operations.
(9) Format the output according to the desired style and precision.



